<?php return array (
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'mpociot/laravel-test-factory-helper' => 
  array (
    'providers' => 
    array (
      0 => 'Mpociot\\LaravelTestFactoryHelper\\TestFactoryHelperServiceProvider',
    ),
  ),
);