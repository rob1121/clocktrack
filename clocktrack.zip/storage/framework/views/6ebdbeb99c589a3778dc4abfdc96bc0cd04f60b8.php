<div class="form-group" id="break-component">
  <div class="col-sm-5"  style="padding: 0">
    <div class="col-sm-6 col-sm-offset-6"  style="padding: 0">
      <input type="text" class="form-control" name="break_in[]">
    </div>
  </div>
  <div class="col-sm-5 col-sm-offset-2"  style="padding: 0">
    <div class="col-sm-6"  style="padding: 0">
      <input type="text" class="form-control" name="break_out[]">
    </div>
  </div>
</div>