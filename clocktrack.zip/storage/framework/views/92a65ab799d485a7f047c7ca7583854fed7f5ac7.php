
  <select name="<?php echo e($accessControlId); ?>" class="form-control" id="<?php echo e($accessControlId); ?>" value="old($accessControlId)">
    <option value="allow all">Allow All</option>
    <option value="allow only">Allow Only</option>
    <option value="allow any except">Allow Any Except</option>
  </select>
  <br/>
  <select 
    id="<?php echo e($id); ?>"
    class="form-control break-time-select"
    multiple="multiple"
    disabled
  >
    <option></option>
    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($option->value); ?>"><?php echo e($option->text); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <input type="hidden" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>">


<?php $__env->startPush('script'); ?>
<script>
  $(document).ready(function() {
    $('#<?php echo e($id); ?>').select2({
      placeholder: 'Select Employee',
      width: '100%',
    });

    $("#<?php echo e($id); ?>").on("select2:select select2:unselect", function (e) {
      $('#<?php echo e($name); ?>').val($('#<?php echo e($id); ?>').select2('val'));
    });

    $('#<?php echo e($accessControlId); ?>').on('change', function() {
      if($(this).val() === 'allow all') {
        $('#<?php echo e($id); ?>').prop('disabled', true);
        $('#<?php echo e($id); ?>').val('').trigger('change');
      } else {
        $('#<?php echo e($id); ?>').prop('disabled', false);
      }
    });

    <?php if($value): ?>
      var val = "<?php echo e($value); ?>";
      
      $('#<?php echo e($id); ?>').val(val.split(',')).trigger('change');
    <?php endif; ?>
  });
</script>
<?php $__env->stopPush(); ?>
      