<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('notification.update', ['notification'=> $notif->id])); ?>">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

            <div class="panel panel-default">
                <div class="panel-heading">Time / Day</div>

                <div class="panel-body">

                        <div class="form-group<?php echo e($errors->has('clock_in') ? ' has-error' : ''); ?>">
                            <label for="clock_in" class="col-md-4 control-label">Send clock in reminder at:</label>

                            <div class="col-md-6">
                                <select name="clock_in" id="clock_in" class="form-control">
                                    <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($time->value); ?>" <?php echo e(old('clock_in', $notif->clock_in) === $time->value ? 'selected' : ''); ?>>
                                            <?php echo e($time->text); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('clock_in')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('clock_in')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="form-group<?php echo e($errors->has('clock_out') ? ' has-error' : ''); ?>">
                            <label for="clock_out" class="col-md-4 control-label">Send clock out remoutder at:</label>

                            <div class="col-md-6">
                            <select name="clock_out" id="clock_out" class="form-control">
                                <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($time->value); ?>" <?php echo e(old('clock_out', $notif->clock_out) === $time->value ? 'selected' : ''); ?>>
                                        <?php echo e($time->text); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                                <?php if($errors->has('clock_out')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('clock_out')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">On these days:</label>
                            <div class="col-md-6">
                                <label class="control-label">
                                    <input type="checkbox" name="monday" <?php echo e(old('monday', $notif->monday) ? 'checked' : ''); ?>>
                                    Mon
                                </label>
                                <label class="control-label">
                                    <input type="checkbox" name="tuesday" <?php echo e(old('tuesday', $notif->tuesday) ? 'checked' : ''); ?>>
                                    Tue
                                </label>
                                <label class="control-label">
                                    <input type="checkbox" name="wednesday" <?php echo e(old('wednesday', $notif->wednesday) ? 'checked' : ''); ?>>
                                    Wed
                                </label>
                                <label class="control-label">
                                    <input type="checkbox" name="thursday" <?php echo e(old('thursday', $notif->thursday) ? 'checked' : ''); ?>>
                                    Thur
                                </label>
                                <label class="control-label">
                                    <input type="checkbox" name="friday" <?php echo e(old('friday', $notif->friday) ? 'checked' : ''); ?>>
                                    Fri
                                </label>
                                <label class="control-label">
                                    <input type="checkbox" name="saturday" <?php echo e(old('saturday', $notif->saturday) ? 'checked' : ''); ?>>
                                    Sat
                                </label>
                                <label class="control-label">
                                    <input type="checkbox" name="sunday" <?php echo e(old('sunday', $notif->sunday) ? 'checked' : ''); ?>>
                                    Sun
                                </label>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <label class="control-label">
                                    <input type="checkbox" name="exclude_admin" <?php echo e(old('exclude_admin', $notif->exclude_admin) ? 'checked' : ''); ?>>
                                    Exclude Admins from these notifications
                                </label>
                            </div>
                        </div>
                </div>
            </div>

            
            <div class="panel panel-default">
                <div class="panel-heading">Schedules</div>

                <div class="panel-body">

                        <div class="form-group<?php echo e($errors->has('schedule_remind_clock_in') ? ' has-error' : ''); ?>">
                            <label for="schedule_remind_clock_in" class="col-md-4 control-label">Send reminder to clock in:</label>

                            <div class="col-md-6">
                                <select name="schedule_remind_clock_in" id="schedule_remind_clock_in" class="form-control">
                                    <option value="15">15 Minutes Before Shift Starts</option>
                                    <option value="30">30 Minutes Before Shift Starts</option>
                                    <option value="60">1 Hour Before Shift Starts</option>
                                </select>

                                <?php if($errors->has('schedule_remind_clock_in')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('schedule_remind_clock_in')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('schedule_remind_clock_out') ? ' has-error' : ''); ?>">
                            <label for="schedule_remind_clock_out" class="col-md-4 control-label">Send reminder to clock out:</label>

                            <div class="col-md-6">
                                <select name="schedule_remind_clock_out" id="schedule_remind_clock_out" class="form-control">
                                    <option value="15">15 Minutes Before Shift Starts</option>
                                    <option value="30">30 Minutes Before Shift Starts</option>
                                    <option value="60">1 Hour Before Shift Starts</option>
                                </select>

                                <?php if($errors->has('schedule_remind_clock_out')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('schedule_remind_clock_out')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                    </div>
                </div>
                        
            <div class="form-group">
                <div class=" col-md-12">
                    <button type="submit" class="btn btn-primary">
                        Update Settings
                    </button>
                </div>
            </div>
        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>