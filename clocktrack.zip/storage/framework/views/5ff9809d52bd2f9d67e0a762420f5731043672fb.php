<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="col-md-4">
        <div class="panel panel-default">
          <div class="panel-heading">
          Time clock
          </div>
          <div class="panel-body">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if($last_biometric && $last_biometric->active): ?>
              <?php echo $__env->make('timeclock.partials.clock_out', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php else: ?>
              <?php echo $__env->make('timeclock.partials.clock_in', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
          </div>
        </div>

        <div class="panel panel-default">
        <div class="panel-heading">
        My Recent Activity
        </div>
        <div class="panel-body">
          <?php echo $__env->make('timeclock.partials.log', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
      </div>


      </div>
      <div class="col-md-8">
        <div class="panel panel-default">
	        <div class="panel-body">
          <ul class="nav nav-tabs">
            <li><a href="<?php echo e(route('timeclock.calendar')); ?>">My Schedule</a></li>
            <li class="active"><a href="<?php echo e(route('timeclock.timesheet', ['user' => Auth::user()->id])); ?>">My Timesheet</a></li>
          </ul>
            <br>
            <div class="tab-content">
                <?php echo $__env->make('timeclock.partials.timesheet', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
          </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>