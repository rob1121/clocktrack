<form action="<?php echo e(route('timesheet.index')); ?>" method="get" id="timeSheetPagination">
    <input 
        type="hidden" 
        name="start_of_week"
        id="start_of_week"
        value="" 
    >
</form>
<div class="btn-group">
    <button 
      type="submit"
      id="prev"
      class="btn btn-primary" 
    >
        <i class="fa fa-angle-left"></i>
    </button>
    <button 
      type="submit"
      id="next"
      class="btn btn-primary"
    >
        <i class="fa fa-angle-right"></i>
    </button>
</div>

<?php
  Carbon::setWeekStartsAt(Carbon::SUNDAY);
  Carbon::setWeekEndsAt(Carbon::SATURDAY);
  
  $startOfWeek = Request::get('start_of_week') 
    ? Carbon::parse(Request::get('start_of_week'))
    : Carbon::now()->startOfWeek();

    $prevWeek = clone $startOfWeek;
    $prevWeek->modify('-1 week');

    $nextWeek = clone $startOfWeek;
    $nextWeek->modify('1 week');
?>

<?php $__env->startPush('script'); ?>
  <script>
    $(document).ready(function() {
      $('#prev').on('click', function(e) {
        e.preventDefault();

        $('#start_of_week').val("<?php echo e($prevWeek); ?>");
        $('#timeSheetPagination').submit();
      });
      
      $('#next').on('click', function(e) {
        e.preventDefault();
        console.log($(this).data('value'));
        $('#start_of_week').val("<?php echo e($nextWeek); ?>");
        $('#timeSheetPagination').submit();
      })
    });
  </script>
<?php $__env->stopPush(); ?>