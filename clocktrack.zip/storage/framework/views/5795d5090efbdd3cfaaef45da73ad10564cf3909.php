<div class="row">
    <div class="col-md-12">
        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <table class="table table-bordered table-hover table-striped">
            <thead>
                <tr>
                    <th></th>
                    <?php for($date=Carbon::now()->startOfWeek();
                            $date->diffInDays(Carbon::now()->endOfWeek())>0;
                            $date->addDay()): ?>
                            <th><?php echo e($date->format('D m/d')); ?></th>
                    <?php endfor; ?>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e(Auth::user()->fullName()); ?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>

                <tr>
                    <td>Total</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>0 hh:mm</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>