<div class="row" id="byJob" hidden>
    <div class="col-md-12">
        <?php if(session('status')): ?>
            <?php $__env->startComponent('components.alert', ['title' => 'Schedule Added', 'icon' => 'check-circle', 'type' => 'success' ]); ?>
            <p><?php echo e(session('status')); ?></p>
            <?php echo $__env->renderComponent(); ?>
        <?php endif; ?>
        
        <?php if($biometrics->isNotEmpty()): ?>
            <div class="panel panel-default">
                <table class="table table-bordered" id="ByEmployeeTable">
                    <thead>
                        <tr>
                            <th></th>
                            <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($day->format('D m/d')); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $biometrics->unique('job')->pluck('job'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <span><?php echo e($job); ?></span>
                            </td>
                                <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <?php
                                            $resultSet = $biometrics->where('job', $job)->filter(function($bt) use($day) {
                                                return str_contains($bt->time_in, $day->format('Y-m-d'));
                                            });
                                        ?>
                                        <?php if($resultSet->isNotEmpty()): ?>
                                            <div class="alert alert-warning">
                                                <div class="sticky">
                                                <a href="<?php echo e(route('schedule.by_job', ['job' => str_slug($job, '-'), 'date' => $day->format('Y-m-d')])); ?>" class="text-success">
                                                    <p>
                                                        <i class="fa fa-edit fa-2x"></i>
                                                    </p>
                                                </a>
                                                <h4>
                                                    <?php echo e(minutesToHourMinuteFormat($resultSet->sum('duration_in_minutes'))); ?>

                                                    <small>hh:mm</small>
                                                </h4>
                                                <small><?php echo e($resultSet->first()->time_in); ?> - <?php echo e($resultSet->last()->time_out); ?></small>
                                                <small><?php echo e($resultSet->pluck('user.fullname_with_no_comma')->implode(', ')); ?></small>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <div class="alert alert-warning">
                                        <div class="sticky">
                                            <h4>
                                                <?php echo e(minutesToHourMinuteFormat($biometrics->where('job', $job)->sum('duration_in_minutes'))); ?>

                                                <small>hh:mm</small>
                                            </h4>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td>Total</td>
                            <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $totalMinutes = $biometrics->filter(function($bt) use($day) {
                                        return str_contains($bt->time_in, $day->format('Y-m-d'));
                                    })->sum('duration_in_minutes');
                                ?>
                                <td>
                                <h4><?php echo e($totalMinutes ? (minutesToHourMinuteFormat($totalMinutes) . ' hh:mm') : ''); ?></h4>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td>
                                <h4><?php echo e(minutesToHourMinuteFormat($biometrics->sum('duration_in_minutes'))); ?> hh:mm</h4>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <?php $__env->startComponent('components.alert', ['title' => 'No Time to Display!', 'icon' => 'info-circle', 'type' => 'info' ]); ?>
                <p>Use the 'Add Time' button above or switch to the 'By Employee' view.</p>
            <?php echo $__env->renderComponent(); ?>
        <?php endif; ?>
    </div>
</div>