<div class="row" id="byJob" hidden>
    <div class="col-md-12">
        <?php if(session('status')): ?>
            <?php $__env->startComponent('components.alert', ['title' => 'Schedule Added', 'icon' => 'check-circle', 'type' => 'success' ]); ?>
            <p><?php echo e(session('status')); ?></p>
            <?php echo $__env->renderComponent(); ?>
        <?php endif; ?>
        
        <?php if($schedules->isNotEmpty()): ?>
            <div class="panel panel-default">
                <table class="table table-bordered" id="ByEmployeeTable">
                    <thead>
                        <tr>
                            <th></th>
                            <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($day->format('D m/d')); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $schedules->unique('job'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <span><?php echo e($schedule->job); ?></span>
                            </td>
                                <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <?php
                                            $resultSet = $schedules->where('job', $schedule->job)->where('start_date', $day->format('Y-m-d'));
                                        ?>
                                        <?php if($resultSet->isNotEmpty()): ?>
                                            <div class="alert alert-warning">
                                                <div class="sticky">
                                                <a href="<?php echo e(route('schedule.by_job', ['job' => str_slug($schedule->job, '-'), 'date' => $day->format('Y-m-d')])); ?>" class="text-success">
                                                    <p>
                                                        <i class="fa fa-edit fa-2x"></i>
                                                    </p>
                                                </a>
                                                <h4>
                                                    <?php echo e(minutesToHourMinuteFormat($resultSet->sum('duration_in_minutes'))); ?>

                                                    <small>hh:mm</small>
                                                </h4>
                                                <small><?php echo e($resultSet->first()->start_time); ?> - <?php echo e($resultSet->last()->end_time); ?></small>
                                                <small><?php echo e($resultSet->pluck('user.fullname_with_no_comma')->implode(', ')); ?></small>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <div class="alert alert-warning">
                                        <div class="sticky">
                                            <h4>
                                                <?php echo e(minutesToHourMinuteFormat($schedules->where('job', $schedule->job)->sum('duration_in_minutes'))); ?>

                                                <small>hh:mm</small>
                                            </h4>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td>Total</td>
                            <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $totalMinutes = $schedules->where('start_date', $day->format('Y-m-d'))->sum('duration_in_minutes');
                                ?>
                                <td>
                                <h4><?php echo e($totalMinutes ? (minutesToHourMinuteFormat($totalMinutes) . ' hh:mm') : ''); ?></h4>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td>
                                <h4><?php echo e(minutesToHourMinuteFormat($schedules->sum('duration_in_minutes'))); ?> hh:mm</h4>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <?php $__env->startComponent('components.alert', ['title' => 'No Time to Display!', 'icon' => 'info-circle', 'type' => 'info' ]); ?>
                <p>Use the 'Add Time' button above or switch to the 'By Employee' view.</p>
            <?php echo $__env->renderComponent(); ?>
        <?php endif; ?>
    </div>
</div>