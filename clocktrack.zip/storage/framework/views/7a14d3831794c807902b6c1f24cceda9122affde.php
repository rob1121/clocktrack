<?php $__env->startPush('script'); ?>
<script>
  $(document).ready(function() {
      /** BUTTONS ACTION AND TRIGGER */
      $('#byEmployeeBtn').on('click', function(e) {
        e.preventDefault();

        $(this).addClass('active');
        $('#byEmployee').show();
        $('#byJobBtn').removeClass('active');
        $('#byJob').hide();
      });

      $('#byJobBtn').on('click', function(e) {
        e.preventDefault();

        $(this).addClass('active');
        $('#byJob').show();
        $('#byEmployeeBtn').removeClass('active');
        $('#byEmployee').hide();
      });
    });
</script>
<?php $__env->stopPush(); ?>