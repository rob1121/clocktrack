<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <?php if(session('status')): ?>
                  <?php $__env->startComponent('components.alert', ['title' => 'Schedule Added', 'icon' => 'check-circle', 'type' => 'success' ]); ?>
                  <p><?php echo e(session('status')); ?></p>
                  <?php echo $__env->renderComponent(); ?>
              <?php endif; ?>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <h1>Tasks</h1>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <a href="<?php echo e(route('task.create')); ?>" class="btn btn-success">
                <span><i class="fa fa-plus"></i></span>
                <span>Add Task</span>
              </a>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="row">
                <div class="form-group col-md-6 col-md-offset-6">
                  <form action="<?php echo e(route('task.index')); ?>" method="get">
                    <div class="input-group">
                        <input name="q" type="text" class="form-control" placeholder="Search for..." value="<?php echo e(Request::get('q')); ?>">
                        <span class="input-group-btn">
                          <button type="submit" class="btn btn-primary" type="button">Search</button>
                          <button class="btn btn-primary" type="button" id="clearBtn">Clear</button>
                        </span>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>  
          
          <div class="row">
            <div class="col-md-12 text-right">
              <?php echo e($tasks->links()); ?>

            </div>
          </div>  

          <div class="row">
            <div class="col-md-12">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Code</th>
                    <th>Date Created</th>
                    <th>Active</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($task->title); ?></td>
                    <td><?php echo e($task->code); ?></td>
                    <td><?php echo e(Carbon::parse($task->created_at)->format('Y-m-d')); ?></td>
                    <td>
                        <input 
                          type="checkbox" 
                          checked="<?php echo e($task->active); ?>" 
                          class="checkbox" 
                          data-id="<?php echo e($task->id); ?>"
                        >
                    </td>
                    <td class="text-right">
                      <a href="<?php echo e(route('task.edit',['task' => $task->id])); ?>" class="btn btn-primary">
                          <i class="fa fa-edit"></i>
                      </a>
                      <a href="#" class="btn btn-primary deleteBtn">
                          <i class="fa fa-trash"></i>
                      </a>
                      <form method="post" action="<?php echo e(route('task.destroy', ['task' => $task->id])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                      </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div> 
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
  <script>
    $(document).ready(function() {
      $('#clearBtn').on('click', function() {
        window.location.href = <?php echo json_encode(route('task.index'), 15, 512) ?>;
      });

      $('.deleteBtn').on('click', function() {
        $(this).siblings('form').submit();
      });

      $('.checkbox').on('change', function() {
        $.ajax({
          url: '/task/' + $(this).data('id') + '/is-active',
          beforeSend: function(xhr){
            xhr.setRequestHeader('X-CSRF-TOKEN', $("#token").attr('content'));
          },
          data: {
            is_active: $(this).is(':checked'),
          },
          dataType: 'JSON',
          type: 'PUT',
        });
      });
    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>