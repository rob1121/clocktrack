<div class="container-fluid">

<?php 
    $start = $week[0];
    $end = $week[count($week)-1];
    $isNotNextMonth = $start->format('M') === $end->format('M');
?>

<div class="row">

    <div class="row form-group">
        <div class="col-xs-2">
            <div class="btn-group">
                <a 
                    href="<?php echo e(route('timeclock.timesheet', [
                        'user' => Auth::user()->id,
                        'start' => $start->modify('-1 week')->format('Y-m-d'),
                        'end' => $end->modify('-1 week')->format('Y-m-d'), 
                    ])); ?>"
                    class="btn btn-primary" 
                >
                    <i class="fa fa-angle-left"></i>
                </a>
                <a 
                    href="<?php echo e(route('timeclock.timesheet', [
                        'user' => Auth::user()->id,
                        'start' => $start->modify('2 week')->format('Y-m-d'),
                        'end' => $end->modify('2 week')->format('Y-m-d'), 
                    ])); ?>"
                    class="btn btn-primary"
                >
                    <i class="fa fa-angle-right"></i>
                </a>
            </div>
        </div>
</div>
<?php if($schedules->isEmpty()): ?>
    <div class="row">
        <div class="col-md-12">
        <p id="noTimesheetFoundComponent"><i>No Time Sheet data to display</i></p>
        </div>
    </div>
<?php else: ?>
    <div class="row">
    <div class="col-xs-6">
        <h1>
            <?php echo e($start->format('M d')); ?>

            -
            <?php echo e($end->format($isNotNextMonth ? 'd Y' : 'M d Y')); ?>

        </h1>
    </div>
    <table class="table table-hover" id="timesheetTable">
    <thead>
        <tr>
        <th>Job</th>
        <th>Task</th>
        <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($day->format('D')); ?></th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($schedule->job); ?></td>
                <td><?php echo e($schedule->task); ?></td>
                <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td>
                    <?php echo e(($day->format('D') === $schedule->date) ? minutesToHourMinuteFormat($schedule->duration) : '-'); ?>

                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e(minutesToHourMinuteFormat($schedule->duration)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="2"></td>
            <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $dailyTotal = $schedules->where('date', $day->format('D'))->sum('duration');
                ?>
                <td>
                    <?php echo e($dailyTotal ? minutesToHourMinuteFormat($dailyTotal): '-'); ?>

                </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <td><?php echo e(minutesToHourMinuteFormat($schedules->sum('duration'))); ?></td>
        </tr>
    </tbody>
    </table>
    </div>
<?php endif; ?>
</div>