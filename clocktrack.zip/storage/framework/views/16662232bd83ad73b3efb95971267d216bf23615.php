<div class="btn-group" data-toggle="buttons">
			
			<label class="btn btn-success <?php echo e(($value === '#20895E') ? 'active' : ''); ?>">
				<input 
          type="radio" 
          name="<?php echo e($name); ?>" 
          id="<?php echo e($name); ?>" 
          autocomplete="off" 
          <?php if($value === '#20895E'): ?>
            checked
          <?php endif; ?>
          value="#20895E"
        >
				<span class="fa fa-check"></span>
			</label>

			<label class="btn btn-primary <?php echo e(($value === '#2579A9') ? 'active' : ''); ?>">
				<input 
          type="radio" 
          name="<?php echo e($name); ?>" 
          id="<?php echo e($name); ?>" 
          autocomplete="off"
          <?php if($value === '#2579A9'): ?>
            checked
          <?php endif; ?>
          value="#2579A9"
        >
				<span class="fa fa-check"></span>
			</label>

			<label class="btn btn-info <?php echo e(($value === '#6B9DBB') ? 'active' : ''); ?>">
				<input 
          type="radio" 
          name="<?php echo e($name); ?>" 
          id="<?php echo e($name); ?>" 
          autocomplete="off" 
          <?php if($value === '#6B9DBB'): ?>
            checked
          <?php endif; ?>
          value="#6B9DBB"
        >
				<span class="fa fa-check"></span>
			</label>

			<label class="btn btn-warning <?php echo e(($value === '#B6A338') ? 'active' : ''); ?>">
				<input 
          type="radio" 
          name="<?php echo e($name); ?>" 
          id="<?php echo e($name); ?>" 
          autocomplete="off" 
          <?php if($value === '#B6A338'): ?>
            checked
          <?php endif; ?>
          value="#B6A338"
        >
				<span class="fa fa-check"></span>
			</label>

			<label class="btn btn-danger <?php echo e(($value === '#954120') ? 'active' : ''); ?>">
				<input 
          type="radio" 
          name="<?php echo e($name); ?>" 
          id="<?php echo e($name); ?>" 
          autocomplete="off" 
          <?php if($value === '#954120'): ?>
            checked
          <?php endif; ?>
          value="#954120"
        >
				<span class="fa fa-check"></span>
			</label>

</div>
<?php $__env->startPush('style'); ?>
<style>
.btn span.fa {    			
	opacity: 0;				
}
.btn.active span.fa {				
	opacity: 1;				
}
</style>
<?php $__env->stopPush(); ?>