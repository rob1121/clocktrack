<?php if(session('deleted')): ?>
    <?php $__env->startComponent('components.alert', ['title' => 'Schedule Deleted', 'icon' => 'check-circle', 'type' => 'success' ]); ?>
    <p><?php echo e(session('deleted')); ?></p>
    <?php echo $__env->renderComponent(); ?>
<?php elseif(session('updated')): ?>
    <?php $__env->startComponent('components.alert', ['title' => 'Schedule Updated', 'icon' => 'check-circle', 'type' => 'success' ]); ?>
    <p><?php echo e(session('updated')); ?></p>
    <?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<div class="panel panel-default">
  <table class="table table-hover">
      <thead>
          <tr>
              <th>In</th>
              <th>Out</th>
              <th>Job</th>
              <th>Task</th>
              <th>Time</th>
              <th></th>
          </tr>
      </thead>
      <tbody>
          <?php if($user->schedule->isNotEmpty()): ?>
              <?php $__currentLoopData = $user->schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e(hourMinuteFormat($schedule->start_time)); ?></td>
                      <td><?php echo e(hourMinuteFormat($schedule->end_time)); ?></td>
                      <td><?php echo e($schedule->job); ?></td>
                      <td><?php echo e($schedule->task); ?></td>
                      <td><?php echo e(minutesToHourMinuteFormat($schedule->duration_in_minutes + $schedule->breaktime->sum('duration_in_minutes'))); ?></td>
                      <td>
                      <a href="<?php echo e(route('schedule.edit', ['schedule' => $schedule->id])); ?>" class="btn btn-primary btn-xs">
                          <i class="fa fa-edit"></i>
                      </a>
                      <?php $__env->startComponent('components.delete_button', [
                        'model' => 'schedule',
                        'modelId' => $schedule->id,
                      ]); ?>
                      <?php echo $__env->renderComponent(); ?>
                      </td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $user->schedule->pluck('breaktime')->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breaktime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="bg-warning">
                      <td colspan="4">Lunch Break: <?php echo e(Carbon::parse($breaktime->break_in)->format('h:i a')); ?> -  <?php echo e(Carbon::parse($breaktime->break_out)->format('h:i a')); ?></td>
                      <td>(<?php echo e(minutesToHourMinuteFormat($breaktime->duration_in_minutes)); ?>)</td>
                      <td></td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-info">
                <td colspan="4"></td>
                <td><strong><?php echo e(minutesToHourMinuteFormat($user->schedule->sum('duration_in_minutes'))); ?></strong></td>
                <td></td>
            </tr>
          <?php else: ?>
              <tr>
                  <td colspan="6" class="text-center">No Schedule found</td>
              </tr>
          <?php endif; ?>
      </tbody>
  </table>
</div>