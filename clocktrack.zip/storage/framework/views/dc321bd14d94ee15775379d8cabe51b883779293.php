<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="col-md-4">
        <div class="panel panel-default">
          <div class="panel-heading">
          Who's Working Now ?
          </div>
          <div class="panel-body">
            No employees are clocked in
          </div>
        </div>
      </div>
      <div class="col-md-8">
        <div class="panel panel-default">
	        <div class="panel-body">
          <ul class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#schedule">My Schedule</a></li>
            <li><a data-toggle="tab" href="#timesheet">My Timesheet</a></li>
          </ul>
            <br>
            <div class="tab-content">
              <div id="schedule" class="tab-pane fade in active">
                <?php echo $__env->make('timeclock.partials.calendar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              </div>
              <div id="timesheet" class="tab-pane fade in">
                <?php echo $__env->make('timeclock.partials.timesheet', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              </div>
            </div>
          </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>