
<table class="table table-hover">
  <thead>
    <tr>
      <th>In</th>
      <th>Out</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = Auth::user()->biometric->sortByDesc('time_out'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $biometric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e(logDateTimeFormat($biometric->time_in)); ?></td>
      <td><?php echo $biometric->active ? "<i>In progress..</i>" : logDateTimeFormat($biometric->time_out); ?></td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
