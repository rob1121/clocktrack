
<table class="table table-hover">
  <thead>
    <tr>
      <th>In</th>
      <th>Out</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = Auth::user()->schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e(logDateTimeFormat($schedule->start_datetime)); ?></td>
      <td><?php echo $schedule->active ? "<i>In progress..</i>" : logDateTimeFormat($schedule->end_datetime); ?></td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
