<a class="btn btn-primary btn-xs" data-toggle="modal" href='#confirmModal'>
    <i class="fa fa-trash-o"></i>
</a>

<form action="<?php echo e(route("{$model}.destroy", [$model => $modelId])); ?>" method="post" id="deleteForm">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('DELETE')); ?>

</form>
<?php $__env->startComponent('components.confirmation', ['id' => '#confirmModal']); ?>
    <h1 class="text-center">Are you sure you want to delete this schedule?</h1>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startPush('script'); ?>
<script>
$(document).ready(function() {
  $('#confirmModal #proceed').on('click', function() {
    $('#deleteForm').submit();
  });
})
</script>
<?php $__env->stopPush(); ?>