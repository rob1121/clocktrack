
<div id="breakTimeSelectContainer" style="display: none">
  <div class="break-select-container">
    <div class="col-sm-5"  style="padding: 0">
      <div class="col-sm-6 col-sm-offset-6"  style="padding: 0;margin-bottom: 10px">
      <?php $__env->startComponent('timesheets.partials.components.time', ['name' => 'break_in[]']); ?>
      <?php echo $__env->renderComponent(); ?>
      </div>
    </div>
    <div class="col-sm-5 col-sm-offset-2"  style="padding: 0;margin-bottom: 10px">
      <div class="col-sm-6"  style="padding: 0">
        <?php $__env->startComponent('timesheets.partials.components.time', ['name' => 'break_out[]']); ?>
        <?php echo $__env->renderComponent(); ?>
      </div>
      <div class="col-sm-6">
        <a class="btn btn-xs btn-danger removeBtn" role="button">
          <i class="fa fa-minus"></i>
        </a>
      </div>
    </div>
  </div>
</div>