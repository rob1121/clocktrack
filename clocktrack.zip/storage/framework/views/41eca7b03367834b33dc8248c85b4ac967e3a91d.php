<select 
  name="<?php echo e($name); ?>" 
  id="<?php echo e($id); ?>"
  class="input form-control break-time-select"
>
  <option></option>
  <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(isset($initVal)): ?>
    <?php endif; ?>
    <option value="<?php echo e($option->value); ?>" <?php if($value === $option->value): ?> selected <?php endif; ?>>
      <?php echo e($option->text); ?>

    </option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>