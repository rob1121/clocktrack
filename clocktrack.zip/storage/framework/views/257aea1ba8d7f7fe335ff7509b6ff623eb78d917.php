<?php
  $options = [];
  $date = Carbon::now()->startOfDay();
  $endOfDate = Carbon::now()->endOfDay();
  while($endOfDate->diffInMinutes($date) > 0) {
    array_push($options, $date->format('h:i a'));
    $date->addMinutes(15);
  }
?>

<select name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" class="form-control break-time-select">
  <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>