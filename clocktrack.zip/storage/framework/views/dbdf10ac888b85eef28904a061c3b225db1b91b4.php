<div class="row" id="byEmployee">
    <div class="col-md-12">
        <div class="panel panel-default">
            <table class="table table-bordered" id="ByEmployeeTable">
                <thead>
                    <tr>
                        <th></th>
                        <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($day->format('D m/d')); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                            <span><?php echo e($user->fullname); ?></span>
                            </td>
                            <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <?php
                                        $resultSet = $user->schedule->where('start_date', $day->format('Y-m-d'));
                                    ?>
                                    <?php if($resultSet->isNotEmpty()): ?>
                                            <div class="alert alert-warning">
                                                <div class="sticky">
                                                <?php if($resultSet->pluck('breaktime')->filter(function($bt) { return $bt->isNotEmpty();})->isNotEmpty()): ?>
                                                    <p><i class="fa fa-cutlery fa-2x"></i></p>
                                                <?php endif; ?>
                                                <a href="<?php echo e(route('schedule.by_employee', ['user' => $user->id, 'date' => $day->format('Y-m-d')])); ?>" class="text-success">
                                                    <i class="fa fa-edit fa-2x"></i>
                                                </a>
                                                <h4>
                                                    <?php echo e(minutesToHourMinuteFormat($resultSet->sum('duration_in_minutes'))); ?>

                                                    <small>hh:mm</small>
                                                </h4>
                                                <small><?php echo e(hourMinuteFormat($resultSet->first()->start_time)); ?> - <?php echo e(hourMinuteFormat($resultSet->last()->end_time)); ?></small>
                                                <small><?php echo e($resultSet->implode('job', ', ')); ?></small>
                                                </div>
                                            </div>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td>
                                <div class="alert alert-warning"
                                <?php if($user->schedule->isEmpty()): ?>
                                    hidden
                                <?php endif; ?>
                                >
                                    <div class="sticky">
                                        <h4>
                                            <?php echo e(minutesToHourMinuteFormat($user->schedule->sum('duration_in_minutes'))); ?>

                                            <small>hh:mm</small>
                                        </h4>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td>Total</td>
                        <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $totalMinutes = $schedules->where('start_date', $day->format('Y-m-d'))->sum('duration_in_minutes');
                        ?>
                            <td>
                            <h4><?php echo e($totalMinutes ? (minutesToHourMinuteFormat($totalMinutes) . ' hh:mm') : ''); ?></h4>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td>
                            <h4><?php echo e(minutesToHourMinuteFormat($schedules->sum('duration_in_minutes'))); ?> hh:mm</h4>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>