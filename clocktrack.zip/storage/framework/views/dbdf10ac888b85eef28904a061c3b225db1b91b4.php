<div class="row" id="byEmployee">
    <div class="col-md-12">
        <div class="panel panel-default">
            <table class="table table-bordered" id="ByEmployeeTable">
                <thead>
                    <tr>
                        <th></th>
                        <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($day->format('D m/d')); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                            <span><?php echo e($employee->fullname); ?></span>
                            </td>
                            <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <?php
                                        $biometric = $employee->biometric();
                                        $biometric = $biometric->where('time_in', 'LIKE', "{$day->format('Y-m-d')}%")->get();
                                        $hasBreakTime = $biometric->pluck('breaktime')->filter(function($bt) { return $bt->isNotEmpty();})->isNotEmpty();
                                    ?>
                                    <?php if($biometric->isNotEmpty()): ?>
                                        <?php
                                            $duration = hourMinuteFormat($biometric->first()->time_in) . ' - ' . hourMinuteFormat($biometric->last()->time_out);
                                        ?>
                                        <div class="alert alert-warning">
                                            <div class="sticky">
                                            <?php if($hasBreakTime): ?>
                                                <p><i class="fa fa-cutlery fa-2x"></i></p>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('schedule.by_employee', ['user' => $employee->id, 'date' => $day->format('Y-m-d')])); ?>" class="text-success">
                                                <i class="fa fa-edit fa-2x"></i>
                                            </a>
                                            <h4>
                                                <?php echo e(minutesToHourMinuteFormat($biometric->sum('duration_in_minutes'))); ?>

                                                <small>hh:mm</small>
                                            </h4>
                                            <small><?php echo e($duration); ?></small>
                                            <small><?php echo e($biometric->implode('job', ', ')); ?></small>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td>
                                <div class="alert alert-warning"
                                <?php if($employee->biometric->isEmpty()): ?>
                                    hidden
                                <?php endif; ?>
                                >
                                    <div class="sticky">
                                        <h4>
                                        <?php if(!empty($employee->biometric)): ?>
                                            <?php echo e(minutesToHourMinuteFormat($employee->biometric->sum('duration_in_minutes'))); ?>

                                        <?php else: ?>
                                            00:00
                                        <?php endif; ?>
                                            <small>hh:mm</small>
                                        </h4>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td>Total</td>
                        <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $totalMinutes = $biometrics->filter(function($bt) use($day) {
                                return str_contains($bt, $day->format('Y-m-d'));
                            })->sum('duration_in_minutes');
                        ?>
                            <td>
                            <h4><?php echo e($totalMinutes ? (minutesToHourMinuteFormat($totalMinutes) . ' hh:mm') : ''); ?></h4>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td>
                            <h4><?php echo e(minutesToHourMinuteFormat($biometrics->sum('duration_in_minutes'))); ?> hh:mm</h4>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
