
  <textarea class="form-control" name="<?php echo e($name); ?>" id="<?php echo e($id); ?>" cols="30" rows="5"><?php echo e($value); ?></textarea>
  <small><span id="counter">500</span> characters remaining (500 maximum)</small>

<?php $__env->startPush('script'); ?>
  <script>
    $(document).ready(function() {
      /**TEXTAREA KEYUP LISTENER */
      $('#<?php echo e($id); ?>').on('keyup', function() {
        var text = $(this).val();
        var charCount = text.length;
        var counter = $('#counter');
        var counterContainer = counter.parent();

        counter.text(500 - charCount);

        if (charCount >= 500) {
          counterContainer.addClass('text-danger');
          $(this).val(text.substr(0,2));
        } else {
          counterContainer.removeClass('text-danger');
        };
      });
    });
  </script>
<?php $__env->stopPush(); ?>