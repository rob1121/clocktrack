<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Edit Schedule</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('shift.update',['shift'=> $schedule->id])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

                        <div class="form-group<?php echo e($errors->has('employee') ? ' has-error' : ''); ?>">
                            <label for="employee" class="col-md-2 control-label">Employee</label>

                            <div class="col-md-9">
                                <select name="employee" id="employee" class="form-control">
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option 
                                    value="<?php echo e($employee->id); ?>" 
                                    <?php echo e(old('employee', $schedule->user_id) === $employee->id ? 'selected' : ''); ?>

                                  ><?php echo e($employee->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php if($errors->has('employee')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('employee')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group<?php echo e($errors->has('job') ? ' has-error' : ''); ?>">
                            <label for="job" class="col-md-2 control-label">Job</label>

                            <div class="col-md-9">
                                <select name="job" id="job" class="form-control">
                                <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option 
                                    value="<?php echo e($job->id); ?>" 
                                    <?php echo e(old('job', $schedule->job) === $job->title ? 'selected' : ''); ?>

                                  ><?php echo e($job->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php if($errors->has('job')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('job')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('notes') ? ' has-error' : ''); ?>">
                            <label for="notes" class="col-md-2 control-label">Notes(Optional)</label>

                            <div class="col-md-9">
                                <textarea 
                                  id="notes" 
                                  type="text" 
                                  class="form-control" 
                                  name="notes"
                                ><?php echo e(old('notes', $schedule->notes)); ?></textarea>

                                <?php if($errors->has('notes')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('notes')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="col-sm-2 control-label">When</label>
                            <div class="col-sm-9">
                            <div class="col-sm-5"  style="padding: 0">
                                <div  style="padding: 0"  class="col-sm-6">
                                    <input 
                                        type="text"
                                        class="form-control" 
                                        name="start_date" 
                                        id="start_date" 
                                        placeholder="Start Date"
                                        value="<?php echo e(old('start_date', $schedule->start_date)); ?>"
                                    >
                                    </div>

                                    <div  style="padding: 0"  class="col-sm-6">
                                    
                                    <select 
                                    name="start_time" 
                                    id="start_time"
                                    class="input form-control break-time-select"
                                    >
                                    <option value="<?php echo e($schedule->start_time); ?>" selected><?php echo e(Carbon::parse($schedule->start_time)->format('H:i a')); ?></option>
                                    <?php $__currentLoopData = $breaktimeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($option->value); ?>" <?php if(old('start_time', $schedule->start_time) === $option->value): ?> selected <?php endif; ?>>
                                        <?php echo e($option->text); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    </div>
                                </div>

                                <div class="col-sm-2 text-center">
                                    <label class="control-label">To</label>
                                </div>
                                
                                <div class="col-sm-5"  style="padding: 0">
                                    <div  style="padding: 0"  class="col-sm-6">
                                    <select 
                                    name="end_time" 
                                    id="end_time"
                                    class="input form-control break-time-select"
                                    >
                                    <option value="<?php echo e($schedule->end_time); ?>" selected><?php echo e(Carbon::parse($schedule->end_time)->format('H:i a')); ?></option>
                                    <?php $__currentLoopData = $breaktimeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($option->value); ?>" <?php if(old('end_time', $schedule->end_time) === $option->value): ?> selected <?php endif; ?>>
                                        <?php echo e($option->text); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    </div>
                                    
                                    <div  style="padding: 0"  class="col-sm-6">  
                                    <input type="text"
                                    class="form-control" 
                                    name="end_date" 
                                    id="end_date" 
                                    placeholder="End Date"
                                        value="<?php echo e(old('end_date', $schedule->end_date)); ?>"
                                    >
                                    </div>
                                </div>
                            </div>
                            </div>


                        <div class="form-group">
                            <div class="col-md-9 col-md-offset-2 text-right">
                                <button type="submit" class="btn btn-primary">
                                    Update Shift
                                </button>

                                <a href="<?php echo e(route('shift.index')); ?>" class="btn btn-default">Cancel</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>