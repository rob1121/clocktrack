<?php $__env->startSection('content'); ?>
<div class="container">
      <h1>Add Time</h1>
      
      <?php if($errors->any()): ?>
          <div class="alert alert-danger">
              <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
      <?php endif; ?>

      <div class="jumbotron">
        <div class="container">
          <form class="form-horizontal" method="post" action="<?php echo e(route('task.store')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
              <label class="col-sm-2 control-label">Title</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" name="title" id="title" placeholder="Name" value="<?php echo e(old('title')); ?>">
              </div>
            </div>

            
            <div class="form-group">
              <label class="col-sm-2 control-label">Task Code(optional)</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" name="code" id="code" placeholder="Name" value="<?php echo e(old('code')); ?>">
              </div>
            </div>

            
            <div class="form-group">
              <label class="col-sm-2 control-label">Access Control</label>
              <div class="col-sm-9">
                <?php $__env->startComponent('components.select2_access_control', [
                  'name' => 'employees', 
                  'id' => 'employees', 
                  'accessControlId' => 'taskAccessControlId',
                  'value' => old('employees'),
                  'options' => $employees
                ]); ?>
                <?php echo $__env->renderComponent(); ?>
              </div>
            </div>
              
            <div class="form-group text-right">
              <div class="col-sm-11">
                <button class="btn btn-primary">Add Task</button>
                <a href="<?php echo e(route('task.index')); ?>" class="btn btn-default">Cancel</a>
              </div>
            </div>
          </form>
        </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>