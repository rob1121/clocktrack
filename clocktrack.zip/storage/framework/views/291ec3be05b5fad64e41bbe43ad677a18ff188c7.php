<div class="alert alert-<?php echo e($type); ?>">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <strong>
        <?php if(isset($icon)): ?>
          <i class="fa fa-<?php echo e($icon); ?>"></i>
        <?php endif; ?>
        <?php if(isset($title)): ?>
          <span><?php echo e($title); ?></span>
        <?php endif; ?>
      </strong>
      <?php echo e($slot); ?>

    </div>