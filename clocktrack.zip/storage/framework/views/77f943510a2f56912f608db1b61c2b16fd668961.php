<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if(session('status')): ?>
            <?php $__env->startComponent('components.alert', ['title' => 'Schedule Added', 'icon' => 'check-circle', 'type' => 'success' ]); ?>
            <p><?php echo e(session('status')); ?></p>
            <?php echo $__env->renderComponent(); ?>
        <?php endif; ?>
        <?php echo $__env->make('timesheets.partials.filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('timesheets.partials.by_employee', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('timesheets.partials.by_job', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('timesheets.partials.script_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>