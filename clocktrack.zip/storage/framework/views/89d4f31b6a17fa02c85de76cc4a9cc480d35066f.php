<select 
  name="<?php echo e($name); ?>"
  id="<?php echo e($id); ?>"
  class="form-control break-time-select"
  multiple="multiple"
>
  <option></option>
  <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($option->value); ?>"><?php echo e($option->text); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<input type="hidden" name="employees" id="employees">

<?php $__env->startPush('script'); ?>
<script>
  
  $(document).ready(function() {
    $('#<?php echo e($id); ?>').select2({
      placeholder: 'Select Employee',
      width: '100%',
    });
    

    $("#<?php echo e($id); ?>").on("select2:select select2:unselect", function (e) {
      $('#employees').val($('#<?php echo e($id); ?>').select2('val'));
    });
  });
</script>
<?php $__env->stopPush(); ?>
      