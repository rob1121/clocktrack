<select 
  name="<?php echo e($name); ?>" 
  id="<?php echo e($id); ?>"
  class="form-control break-time-select"
  <?php if(isset($multiple) && $multiple): ?>
    multiple="multiple"
  <?php endif; ?>
>
  <option></option>
  <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($option->value); ?>"><?php echo e($option->text); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<?php $__env->startPush('script'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/js/select2.min.js"></script>
<script>
  
  $(document).ready(function() {
    /** SELECT2 COMPONENTS */
      $('#<?php echo e($id); ?>').select2({
          placeholder: 'Select  Job',
          width: '100%',
      });
      
      $('#<?php echo e($id); ?>').val('<?php echo e($value); ?>').trigger('change');
  });
</script>
<?php $__env->stopPush(); ?>