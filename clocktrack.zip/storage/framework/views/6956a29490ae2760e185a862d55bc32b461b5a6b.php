<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <?php if(session('status')): ?>
                  <?php $__env->startComponent('components.alert', ['title' => 'Schedule Added', 'icon' => 'check-circle', 'type' => 'success' ]); ?>
                  <p><?php echo e(session('status')); ?></p>
                  <?php echo $__env->renderComponent(); ?>
              <?php endif; ?>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <h1>Employees</h1>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <a href="<?php echo e(route('employee.create')); ?>" class="btn btn-success">
                <span><i class="fa fa-plus"></i></span>
                <span>Add Employee</span>
              </a>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="row">
                <div class="form-group col-md-6 col-md-offset-6">
                  <form action="<?php echo e(route('employee.index')); ?>" method="get">
                    <div class="input-group">
                        <input name="q" type="text" class="form-control" placeholder="Search for..." value="<?php echo e(Request::get('q')); ?>">
                        <span class="input-group-btn">
                          <button type="submit" class="btn btn-primary" type="button">Search</button>
                          <button class="btn btn-primary" type="button" id="clearBtn">Clear</button>
                        </span>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>  
          
          <div class="row">
            <div class="col-md-12 text-right">
              <?php echo e($employees->links()); ?>

            </div>
          </div>  

          <div class="row">
            <div class="col-md-12">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Date Created</th>
                    <th>Active</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($employee->fullname); ?></td>
                    <td><?php echo e($employee->email); ?></td>
                    <td><?php echo e($employee->phone); ?></td>
                    <td><?php echo e(Carbon::parse($employee->created_at)->format('Y-m-d')); ?></td>
                    <td class="text-right">
                      <a href="<?php echo e(route('employee.edit',['employee' => $employee->id])); ?>" class="btn btn-primary">
                          <i class="fa fa-edit"></i>
                      </a>
                      <a href="#" class="btn btn-primary deleteBtn">
                          <i class="fa fa-trash"></i>
                      </a>
                      <form method="post" action="<?php echo e(route('employee.destroy', ['employee' => $employee->id])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                      </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div> 
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
  <script>
    $(document).ready(function() {
      $('#clearBtn').on('click', function() {
        window.location.href = <?php echo json_encode(route('employee.index'), 15, 512) ?>;
      });

      $('.deleteBtn').on('click', function() {
        $(this).siblings('form').submit();
      });

      $('.checkbox').on('change', function() {
        $.ajax({
          url: '/employee/' + $(this).data('id') + '/is-active',
          beforeSend: function(xhr){
            xhr.setRequestHeader('X-CSRF-TOKEN', $("#token").attr('content'));
          },
          data: {
            is_active: $(this).is(':checked'),
          },
          dataType: 'JSON',
          type: 'PUT',
        });
      });
    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>