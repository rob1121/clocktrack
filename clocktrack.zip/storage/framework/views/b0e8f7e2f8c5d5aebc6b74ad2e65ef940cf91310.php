<?php $__env->startSection('content'); ?>
<div class="container">
      <h1>Add Time</h1>
      
      <?php if($errors->any()): ?>
          <div class="alert alert-danger">
              <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
      <?php endif; ?>

      <div class="jumbotron">
        <div class="container">
          <form class="form-horizontal" method="post" action="<?php echo e(route('job.update',['job' => $job->id])); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

            <div class="form-group">
              <label class="col-sm-2 control-label">Title</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" name="title" id="title" placeholder="Name" value="<?php echo e(old('title', $job->title)); ?>">
              </div>
            </div>

            
            <div class="form-group">
              <label class="col-sm-2 control-label">Job Number(optional)</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" name="number" placeholder="Job Number" id="number" value="<?php echo e(old('number', $job->number)); ?>">
              </div>
            </div>
            

            <div class="form-group">
              <label class="col-sm-2 control-label">Description(optional)</label>
              <div class="col-sm-9">
                <textarea name="description" id="description" class="form-control" rows="10"><?php echo e(old('description', $job->description)); ?></textarea>
              </div>
            </div>
            

            <div class="form-group">
              <div class="col-sm-9 col-sm-offset-2">
                <label class="control-label">Attachment</label>
                <input type="file" name="file" id="file" >
              </div>
            </div>

            
            <div class="form-group">
              <label class="col-sm-2 control-label">Color</label>
              <div class="col-sm-9">
                <?php $__env->startComponent('components.color', ['name' => 'color', 'value' => old('color', $job->color)]); ?>
                <?php echo $__env->renderComponent(); ?>
              </div>
            </div>

            
            <div class="form-group">
              <label class="col-sm-2 control-label">Access Control</label>
              <div class="col-sm-9">
                <?php $__env->startComponent('components.select2_multiple', [
                  'name' => 'employees', 
                  'id' => 'select2_employees', 
                  'value' => old('employees', $selectedEmployees),
                  'options' => $employees
                ]); ?>
                <?php echo $__env->renderComponent(); ?>
              </div>
            </div>

            
            <div class="form-group">
              <label class="col-sm-2 control-label">Task Control</label>
              <div class="col-sm-9">
                <?php $__env->startComponent('components.select2_multiple', [
                  'name' => 'tasks', 
                  'id' => 'select2_tasks', 
                  'value' => old('tasks', $selectedTasks),
                  'options' => $tasks
                ]); ?>
                <?php echo $__env->renderComponent(); ?>
              </div>
            </div>



            <div class="form-group">
              <label class="col-sm-2 control-label">Labor budget</label>
              <div class="col-sm-9">
                <div class="checkbox">
                  <label>
                    <input type="checkbox" value="1" name="track_labor_budget" id="track_labor_budget" <?php echo e(old('track_labor_budget', $job->track_labor_budget) ? 'checked' : ''); ?>>
                    Track Budgeted Hours
                  </label>
                </div>
                <input type="text" class="form-control" name="total_hour_target" id="total_hour_target" value="<?php echo e(old('total_hour_target', $job->total_hour_target)); ?>" disabled>
              </div>
            </div>



            <div class="form-group">
              <label class="col-sm-2 control-label">Trask hours remaining</label>
              <div class="col-sm-9">
                <div class="checkbox">
                  <label>
                    <input type="checkbox" value="1" name="track_when_budget_hits" id="track_when_budget_hits" <?php echo e(old('track_when_budget_hits', $job->track_when_budget_hits) ? 'checked' : ''); ?>>
                      Track Remaining Hours
                    </label>
                </div>
                <input type="text" class="form-control" name="hours_remaining" id="hours_remaining" value="<?php echo e(old('hours_remaining', $job->hours_remaining)); ?>" disabled>
              </div>
            </div>
            

            <div class="form-group">
              <label class="col-sm-2 control-label">Job Address</label>
              <div class="col-sm-9">
                <div class="row">
                  <div class="col-sm-12">
                    <label>Address</label>
                    <textarea name="address" id="address" class="form-control" rows="10"><?php echo e(old('address', $job->address)); ?></textarea>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-12">
                    <div class="row">
                      <div class="col-sm-6">
                          <label>City</label>
                          <input type="text" class="form-control" name="city" placeholder="City" id="city" value="<?php echo e(old('city', $job->city)); ?>">
                        </div>
                      <div class="col-sm-6">
                          <label>State/Province</label>
                          <input type="text" class="form-control" name="state" placeholder="State" id="state" value="<?php echo e(old('state', $job->state)); ?>">
                        </div>
                    </div>
                  </div>
                  </div>
                  
                <div class="row">
                  <div class="col-sm-12">
                    <div class="row">
                      <div class="col-sm-6">
                          <label>Postal Code</label>
                          <input type="text" class="form-control" name="postal_code" placeholder="postal_code" id="postal_code" value="<?php echo e(old('postal_code', $job->postal_code)); ?>">
                        </div>
                      <div class="col-sm-6">
                          <label>Country</label>
                          <input type="text" class="form-control" name="country" placeholder="country" id="country" value="<?php echo e(old('country', $job->country)); ?>">
                        </div>
                    </div>
                  </div>
                  </div>
              </div>
            </div>
            
            <div class="form-group">
              <div class="col-sm-9 col-sm-offset-2">
                <div class="checkbox">
                  <label>
                    <input type="checkbox" value="1" name="remind_clockin" id="remind_clockin" <?php echo e(old('remind_clockin', $job->remind_clockin) ? 'checked' : ''); ?>>
                    Remind Employee to clock in
                  </label>
                </div>
                
                <div class="checkbox">
                  <label>
                    <input type="checkbox"  name="remind_clockout" id="remind_clockout" value="1" <?php echo e(old('remind_clockout', $job->remind_clockout) ? 'checked' : ''); ?>>
                    Remind Employee to clock out
                  </label>
                </div>
              </div>
            </div>

                  
            <div class="row">
              <div class="col-sm-11 text-right">
                  <button type="submit" class="btn btn-primary">Update Job</button>
                  <a href="<?php echo e(route('job.index')); ?>" class="btn btn-primary">Cancel</a>
              </div>
            </div>
          </form>
        </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
  $('#track_labor_budget').on('change',function() {
    $('#total_hour_target').prop('disabled', !$(this).is(':checked'));
  });

  $('#track_when_budget_hits').on('change',function() {
    $('#hours_remaining').prop('disabled', !$(this).is(':checked'));
  });
  
  $(document).ready(function() {
    $('#total_hour_target').prop('disabled', !$('#track_labor_budget').is(':checked'));
    $('#hours_remaining').prop('disabled', !$('#track_when_budget_hits').is(':checked'));
  })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>