<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <?php if(session('status')): ?>
                <div class="row">
                  <div class="col-md-12">
                        <?php $__env->startComponent('components.alert', ['title' => 'Schedule Added', 'icon' => 'check-circle', 'type' => 'success' ]); ?>
                        <p><?php echo e(session('status')); ?></p>
                        <?php echo $__env->renderComponent(); ?>
                  </div>
                </div>
              <?php endif; ?>
              <h1>Jobs</h1>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <a href="<?php echo e(route('job.create')); ?>" class="btn btn-success">
                <span><i class="fa fa-plus"></i></span>
                <span>Add Job</span>
              </a>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="row">
                <div class="form-group col-md-6 col-md-offset-6">
                  <form action="<?php echo e(route('job.index')); ?>" method="get">
                    <div class="input-group">
                        <input name="q" type="text" class="form-control" placeholder="Search for..." value="<?php echo e(Request::get('q')); ?>">
                        <span class="input-group-btn">
                          <button type="submit" class="btn btn-primary" type="button">Search</button>
                          <button class="btn btn-primary" type="button" id="clearBtn">Clear</button>
                        </span>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>  
          
          <div class="row">
            <div class="col-md-12 text-right">
              <?php echo e($jobs->links()); ?>

            </div>
          </div>  

          <div class="row">
            <div class="col-md-12">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Number</th>
                    <th class="text-right">Hour Budgeted</th>
                    <th class="text-right">Houts Worked</th>
                    <th>Date Created</th>
                    <th>Active</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($job->title); ?></td>
                    <td><?php echo e($job->number ?: '-'); ?></td>
                    <td class="text-right"><?php echo e($job->total_hour_target ?: '-'); ?></td>
                    <td class="text-right"><?php echo e($job->hours_remaining ?: '-'); ?></td>
                    <td><?php echo e(Carbon::parse($job->created_at)->format('Y-m-d')); ?></td>
                    <td>
                        <input 
                          type="checkbox" 
                          class="checkbox" 
                          data-id="<?php echo e($job->id); ?>"
                          <?php echo e($job->active === 1 ? 'checked' : ''); ?>

                        >
                    </td>
                    <td class="text-right">
                      <a href="<?php echo e(route('job.edit',['job' => $job->id])); ?>" class="btn btn-primary">
                          <i class="fa fa-edit"></i>
                      </a>
                      <a href="#" class="btn btn-primary deleteBtn">
                          <i class="fa fa-trash"></i>
                      </a>
                      <form method="post" action="<?php echo e(route('job.destroy', ['job' => $job->id])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                      </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div> 
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
  <script>
    $(document).ready(function() {
      $('#clearBtn').on('click', function() {
        window.location.href = <?php echo json_encode(route('job.index'), 15, 512) ?>;
      });

      $('.deleteBtn').on('click', function() {
        $(this).siblings('form').submit();
      });

      $('.checkbox').on('change', function() {
        $.ajax({
          url: <?php echo json_encode(Request::root(), 15, 512) ?> + '/job/' + $(this).data('id') + '/is-active',
          beforeSend: function(xhr){
            xhr.setRequestHeader('X-CSRF-TOKEN', $("#token").attr('content'));
          },
          data: {
            is_active: $(this).is(':checked'),
          },
          dataType: 'JSON',
          type: 'PUT',
        });
      });
    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>