
<div class="alert alert-warning">
    <div class="sticky">
    <a href="#" class="text-success">
        <p>
            <i class="fa fa-edit fa-2x"></i>
        </p>
    </a>
    <h4>
        <?php echo e(minutesToHourMinuteFormat($minutes)); ?>

        <small>hh:mm</small>
    </h4>
    <small><?php echo e("{$schedule->start_time} - {$schedule->end_time}"); ?></small>
    <?php echo e($slot); ?>

    </div>
</div>