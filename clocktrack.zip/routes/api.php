<?php

use Illuminate\Http\Request;
use App\Schedule;
use App\User;
use Carbon\Carbon;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('/schedules', function (Request $request) {
    $schedules = Schedule::whereBetween('start_date', [$request->start, $request->end]);
    $schedules = $schedules->where('user_id', $request->user);
    $schedules = $schedules->get();
    $schedules = $schedules->map(function($schedule) {
        return [
            'title' => $schedule->job,
            'body' => $schedule->job_description ?: '',
            'schedule' => Carbon::parse($schedule->start_date)->format('m/d'),
            'start' => "{$schedule->start_date} {$schedule->start_time}",
            'end' => "{$schedule->end_date} {$schedule->end_time}",
        ];
    });

    return $schedules;
})->name('api.schedules');