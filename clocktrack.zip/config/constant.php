<?php 
return [
  'dateFormat' => 'Y-m-d',
  'timeFormat' => 'H:i:s',
  'dateTimeFormat' => 'Y-m-d H:i:s',
];