<?php 
return [
  'dateFormat' => 'Y-m-d',
  'dateIndexFormat' => 'm/d/Y',
  'timeFormat' => 'H:i:s',
  'dateTimeFormat' => 'Y-m-d H:i:s',
];